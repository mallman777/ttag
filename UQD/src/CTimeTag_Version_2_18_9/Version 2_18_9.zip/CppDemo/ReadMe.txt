This is a simple console application for the time tag unit. 


Windows
-------
It was tested with Visual Studio 2010

All the interface files are in the folder "CTimeTag"
* CTimeTagLib.lib
* CTimeTag.h
* CLogic.h    (Additional interface for devices with special logic feature)

Linux
-----
Copy the apropriate .so (32/64 bit) file from /CppDemo/Linx to your lib directory
Go to the CppDemo directory
Build using make
